﻿using System;

namespace gameAMS.Application
{
    public class Class1
    {
    }
}
