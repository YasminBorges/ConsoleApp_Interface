using  gameAms.Interface;
namespace gameAMS.Application
{
    public class JogoAms
    {
        private readonly Ijogador _jogadorA;
        private readonly Ijogador _jogadorB;
        public JogoAms(Ijogador jogadorA , Ijogador jogadorB)
        {
            _jogadorA=jogadorA;
            _jogadorB=jogadorB;
        }
        public void IniciarJogo()
        {
            System.Console.WriteLine("Jogo iniciado \n");

            System.Console.WriteLine($"Primeiro(a) jogador(a) :\n");
            System.Console.WriteLine($"{_jogadorA.Chutar()};");
            System.Console.WriteLine($"{_jogadorA.Correr()};");
            System.Console.WriteLine($"{_jogadorA.Passar()}.\n");

            System.Console.WriteLine($"Segundo(a) jogador(a) :\n");
            System.Console.WriteLine($"{_jogadorB.Chutar()};");
            System.Console.WriteLine($"{_jogadorB.Correr()};");
            System.Console.WriteLine($"{_jogadorB.Passar()}.\n");
        }
    }
}