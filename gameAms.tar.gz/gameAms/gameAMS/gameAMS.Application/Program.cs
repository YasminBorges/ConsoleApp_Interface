﻿using System;
using gameAms.Service;

namespace gameAMS.Application
{
    class Program
    {
        static void Main(string[] args)
        {
            var jogo = new JogoAms(
                new Jogador1("Yasmin"),
                new Jogador2("Maria")
            );
            jogo.IniciarJogo();
        }
    }
}
