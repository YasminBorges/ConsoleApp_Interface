﻿using System;

namespace gameAms.Service
{
    public class Class1
    {
    }
}
