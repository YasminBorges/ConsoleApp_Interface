using  gameAms.Interface;
namespace gameAms.Service
{
    public class Jogador1 : Ijogador
    {
        public readonly string Nome;
        public Jogador1(string nome = "Yasmin")
        {
            Nome=nome;
        }
        public string Chutar()
        {
             return $"{Nome} está chutando a bola";
        }
        public string Correr()
        {
            return $"{Nome} está correndo com a bola";
        }
        public string Passar()
        {
            return $"{Nome} está passando a bola";
        }
    }
}