using  gameAms.Interface;
namespace gameAms.Service
{
    public class Jogador2 : Ijogador 
    {
        public readonly string Nome;
        public Jogador2(string nome = "Yasmin")
        {
            Nome=nome;
        }
        public string Chutar ()
        {
            return $"{Nome} está chutando a bola";
        }
        public string Correr ()
        {
            return $"{Nome} está correndo com a bola";
        }
        public string Passar ()
        {
            return $"{Nome} está passando a bola";
        }
    }
}