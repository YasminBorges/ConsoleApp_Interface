using System;

namespace  gameAms.Interface
{

    
        public interface Ijogador
        {
            string Chutar();
            string Correr();
            string Passar();
        }

     
}