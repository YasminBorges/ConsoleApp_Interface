﻿using System;

namespace gameAms.Interface
{
    public class Class1
    {
    }
}
